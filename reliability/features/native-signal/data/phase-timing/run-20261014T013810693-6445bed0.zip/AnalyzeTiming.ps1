param([Parameter(Mandatory)][string]$SourceRoot)
$ErrorActionPreference = 'Stop'
function Require([bool]$Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
$environment = Get-Content (Join-Path $PSScriptRoot 'environment.json') -Raw | ConvertFrom-Json
foreach ($entry in $environment.hashes.PSObject.Properties) {
    Require ((Get-FileHash -LiteralPath (Join-Path $SourceRoot $entry.Name)).Hash -eq $entry.Value) "Source/binary hash differs: $($entry.Name)"
}
$results = @(foreach ($file in Get-ChildItem (Join-Path $PSScriptRoot 'block-*-speedup-*.json')) {
    $case = Get-Content $file -Raw | ConvertFrom-Json
    Require ($case.protocolPassed -and $null -ne $case.measurement) "Analysis requires a completed protocol: $($file.Name)"
    $frequency = [double]$case.stopwatchFrequency
    Require ($frequency -gt 0) 'Stopwatch frequency is missing.'
    $requests = @{}
    foreach ($request in $case.requests) {
        Require (-not $requests.ContainsKey($request.Sequence)) 'A native sequence repeats.'
        $requests.Add($request.Sequence, $request)
        $duration = 1000 * ($request.CompletedTimestamp - $request.StartedTimestamp) / $frequency
        Require ($duration -ge 0 -and [math]::Abs($duration - $request.AcknowledgmentMilliseconds) -le 0.000101) 'Request timestamps disagree with acknowledgment duration.'
    }
    $phases = @(
        @{name='warmup'; settled='warmup-settlement'; boundary=$case.warmup.Measurement; final=$case.warmup.Settled; peaks=$case.warmup.PeakDebt; maximum=$case.warmup.MaxDebtNanoseconds; interval=$case.warmup.LongestServiceInterval},
        @{name='measurement'; settled='settlement'; boundary=$case.measurement; final=$case.settled; peaks=$case.peakDebt; maximum=$case.maxDebtNanoseconds; interval=$case.longestServiceInterval}
    )
    foreach ($phase in $phases) {
        $credit = ($case.samples | Where-Object Stage -eq $phase.name | Measure-Object CreditNanoseconds -Sum).Sum
        Require ($credit -eq $phase.boundary.CreditNanoseconds) 'Sample credits differ from the phase boundary.'
        Require ($phase.final.Pending -eq 0 -and -not ($phase.final.Registered -contains $true)) 'Final ledger retirement is incomplete.'
        foreach ($slot in 0..1) {
            $live = ($case.requests | Where-Object { $_.Slot -eq $slot -and $_.Stage -eq $phase.name } | ForEach-Object { $_.Result.WaitNanoseconds } | Measure-Object -Sum).Sum
            $final = ($case.requests | Where-Object { $_.Slot -eq $slot -and $_.Stage -in @($phase.name,$phase.settled) } | ForEach-Object { $_.Result.WaitNanoseconds } | Measure-Object -Sum).Sum
            Require ($live -eq $phase.boundary.WaitNanoseconds[$slot] -and $final -eq $phase.final.WaitNanoseconds[$slot]) 'Acknowledged waits differ from ledger totals.'
            $peak = $phase.peaks[$slot]
            if ($phase.maximum[$slot] -eq 0) { Require ($null -eq $peak) 'A zero maximum has a peak record.'; continue }
            Require ($peak.Slot -eq $slot -and $peak.Boundary.Stage -eq $phase.name -and $peak.Boundary.DebtNanoseconds[$slot] -eq $phase.maximum[$slot]) 'Peak debt differs from the phase maximum.'
            Require ($peak.Interval.FinishedTimestamp -le $peak.Boundary.Timestamp) 'A peak predates its completed service interval.'
            foreach ($sequence in $peak.LastAcknowledgedSequences) {
                if ($sequence -eq 0) { continue }
                Require ($requests.ContainsKey($sequence) -and $requests[$sequence].CompletedTimestamp -le $peak.Interval.FinishedTimestamp) 'A peak references an acknowledgment from the future.'
            }
            Require ($peak.Boundary.Pending -eq @($peak.Boundary.PendingRequests).Count) 'Pending counts differ.'
            foreach ($pending in $peak.Boundary.PendingRequests) {
                Require ($requests.ContainsKey($pending.Sequence)) 'A pending sequence has no eventual acknowledgment.'
                $ack = $requests[$pending.Sequence]
                Require ($ack.Slot -eq $pending.Slot -and $ack.StartedTimestamp -eq $pending.StartedTimestamp -and $ack.StartedStage -eq $pending.StartedStage) 'Pending identity differs from its acknowledgment.'
                Require ($pending.StartedTimestamp -le $peak.Interval.FinishedTimestamp -and $ack.CompletedTimestamp -ge $peak.Boundary.Timestamp) 'Pending lifetime does not contain the peak.'
            }
        }
        $intervals = @($phase.interval) + @($phase.peaks | Where-Object { $null -ne $_ } | ForEach-Object Interval)
        foreach ($interval in $intervals) {
            Require ($interval.StartedTimestamp -le $interval.FinishedTimestamp -and $interval.SamplesBefore -le $interval.SamplesAfter -and $interval.SamplesAfter -le $case.samples.Count) 'Service interval is invalid.'
            for ($index = $interval.SamplesBefore; $index -lt $interval.SamplesAfter; $index++) {
                $sample = $case.samples[$index]
                Require ($sample.Stage -eq $phase.name -and $sample.ConsumedTimestamp -ge $interval.StartedTimestamp -and $sample.ConsumedTimestamp -le $interval.FinishedTimestamp) 'Consumed sample falls outside its service interval.'
            }
        }
    }
    @{ file=$file.Name; protocolPassed=$case.protocolPassed; capacityPassed=$case.capacityPassed; peakDebtNanoseconds=$case.maxDebtNanoseconds;
       longestServiceMilliseconds=1000*($case.longestServiceInterval.FinishedTimestamp-$case.longestServiceInterval.StartedTimestamp)/$frequency;
       peakDebt=$case.peakDebt; requestCount=$case.requests.Count; phasesVerified=2 }
})
@{ hashesVerified=@($environment.hashes.PSObject.Properties).Count; cases=$results } | ConvertTo-Json -Depth 12 | Set-Content (Join-Path $PSScriptRoot 'timing-analysis.json')
