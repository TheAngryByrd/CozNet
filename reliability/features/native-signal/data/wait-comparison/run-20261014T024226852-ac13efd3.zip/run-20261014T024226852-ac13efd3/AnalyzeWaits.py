import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())

hashes = read(root / 'measured-hashes.json')
for name, expected in hashes.items():
    assert hashlib.sha256((root / 'measured' / name).read_bytes()).hexdigest().upper() == expected

basic_dir, = (root / 'basic').glob('run-*')
sampled_dir, = (root / 'sampled').glob('run-*')
basic, sampled = [], []
for folder, rows in ((basic_dir, basic), (sampled_dir, sampled)):
    outcomes = read(folder / 'outcomes.json')
    for outcome in outcomes:
        assert outcome['recordExists']
        if 'file' not in outcome:
            assert outcome['exitCode'] == 0
            continue
        case = read(folder / outcome['file'])
        assert case['passed'] == (outcome['exitCode'] == 0)
        assert case['joined'] and case['restored']
        if folder == basic_dir:
            mode, kind, gc = outcome['case'].split(':')
            assert case['nativeRange']['waitMode'] == mode
            assert case['forcedGc'] == (gc == 'gc')
            assert case['sendSignals'] == (kind != 'baseline')
            assert case['requestedDelayNanoseconds'] == (50000 if kind == 'delay' else 0)
            if kind == 'delay':
                for slot in (0, 1):
                    assert any(r['Slot'] == slot and r['Result']['Outcome'] == 2 and r['Result']['WaitNanoseconds'] > 0 for r in case['requests'])
            cpu = case['processCpuEndTicks'] - case['processCpuStartTicks']
            assert cpu >= 0
            rows.append(dict(file=outcome['file'], mode=mode, kind=kind, gc=gc,
                passed=case['passed'], processCpuMilliseconds=cpu/10000,
                maximumHandlerMilliseconds=max((r['Result']['MeasuredHandlerNanoseconds']/1e6 for r in case['requests']), default=0),
                maximumGcCallMilliseconds=max((r['CallMilliseconds'] for r in case['collections']), default=0)))
        else:
            assert case['backendDetails']['waitMode'] == outcome['waitMode']
            assert case['percent'] == outcome['percent']
            assert case['passed'] == (case['protocolPassed'] and case['capacityPassed'])
            end = case['measurement'] or case['failureBoundary']
            assert end['Stage'] == case['runtimeCountersStart']['Stage']
            cpu = end['RuntimeCounters']['ProcessCpuTicks'] - case['runtimeCountersStart']['ProcessCpuTicks']
            assert cpu >= 0
            rows.append(dict(file=outcome['file'], mode=outcome['waitMode'], block=outcome['iteration'], percent=case['percent'],
                protocolPassed=case['protocolPassed'], capacityPassed=case['capacityPassed'], measurementCompleted=case['measurement'] is not None,
                observedMilliseconds=end['Milliseconds'], processCpuMilliseconds=cpu/10000,
                peakPeerDebtMilliseconds=case['maxDebtNanoseconds'][1]/1e6,
                maximumHandlerMilliseconds=max((r['Result']['MeasuredHandlerNanoseconds']/1e6 for r in case['requests']), default=0)))

assert len(basic) == 12
assert {(r['mode'],r['kind'],r['gc']) for r in basic} == {(m,k,g) for m in ('sleep','spin') for k in ('baseline','zero','delay') for g in ('gc','no-gc')}
assert len(sampled) == 12
assert {(r['mode'],r['block'],r['percent']) for r in sampled} == {(m,b,p) for m in ('sleep','spin') for b in (1,2,3) for p in (0,50)}
(root / 'analysis.json').write_text(json.dumps(dict(hashesVerified=len(hashes),basic=basic,sampled=sampled), indent=2))
