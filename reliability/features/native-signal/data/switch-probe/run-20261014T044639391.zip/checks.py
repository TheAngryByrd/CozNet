import struct
import unittest
from analyze import decode, intervals, Switch, Loss


def switch(time=10, out=False, preempt=False, pid=1, tid=2):
    return struct.pack("<IHHIIQ", 14, (out << 13) | (preempt << 14), 24, pid, tid, time)


class DecoderChecks(unittest.TestCase):
    def test_round_trip_and_flags(self):
        raw = switch(out=True, preempt=True) + switch(20)
        self.assertEqual(decode(raw, 1, 2, 0, 30), [Switch(10, True, True), Switch(20, False, False)])
        pairs, left, right = intervals(decode(raw, 1, 2, 0, 30))
        self.assertEqual((pairs[0]["duration"], left, right), (10, 0, False))

    def test_rejects_truncation(self):
        raw = switch()
        for length in range(1, len(raw)):
            with self.subTest(length=length), self.assertRaises(ValueError):
                decode(raw[:length], 1, 2, 0, 30)

    def test_rejects_identity_flags_and_order(self):
        for raw in [switch(pid=3), switch(tid=4), switch(preempt=True), switch(31),
                    switch(20) + switch(10, out=True)]:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                decode(raw, 1, 2, 0, 30)

    def test_loss_resets_pairing(self):
        raw = switch(out=True) + struct.pack("<IHHQQIIQ", 2, 0, 40, 7, 5, 1, 2, 15) + switch(20)
        records = decode(raw, 1, 2, 0, 30)
        self.assertEqual(records[1], Loss(15, 5))
        self.assertEqual(intervals(records), ([], 1, False))

    def test_censored_edges(self):
        self.assertEqual(intervals([Switch(10, False, False), Switch(20, True, False)]), ([], 1, True))

    def test_rejects_repeated_transition(self):
        for out in [True, False]:
            with self.subTest(out=out), self.assertRaises(ValueError):
                intervals([Switch(10, out, False), Switch(20, out, False)])

    def test_rejects_size_and_cpu_wide_type(self):
        for kind, size in [(15, 24), (14, 16), (14, 32)]:
            with self.subTest(kind=kind, size=size), self.assertRaises(ValueError):
                decode(struct.pack("<IHHIIQ", kind, 0, size, 1, 2, 10), 1, 2, 0, 30)


if __name__ == "__main__":
    unittest.main()
