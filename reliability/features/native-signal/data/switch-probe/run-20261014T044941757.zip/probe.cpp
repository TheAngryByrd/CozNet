#include <linux/perf_event.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <time.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <atomic>
#include <thread>

static void copy_ring(unsigned char* output, const unsigned char* ring, size_t size, uint64_t start, size_t count) {
    for (size_t i = 0; i < count; ++i) output[i] = ring[(start + i) % size];
}

static bool check_copy() {
    unsigned char ring[64]{};
    unsigned char output[40]{};
    for (size_t start = 0; start < 128; ++start) {
        for (size_t count : {size_t(8), size_t(24), size_t(40)}) {
            for (size_t i = 0; i < count; ++i) ring[(start + i) % 64] = static_cast<unsigned char>(i + 1);
            copy_ring(output, ring, 64, start, count);
            for (size_t i = 0; i < count; ++i) if (output[i] != i + 1) return false;
        }
    }
    return true;
}

static uint64_t now() {
    timespec t{};
    if (clock_gettime(CLOCK_MONOTONIC, &t)) _exit(90);
    return uint64_t(t.tv_sec) * 1000000000 + t.tv_nsec;
}

int main(int argc, char** argv) {
    if (argc != 2 || (strcmp(argv[1], "normal") && strcmp(argv[1], "overflow") && strcmp(argv[1], "concurrent"))) return 64;
    if (!check_copy()) return 65;
    const bool overflow = !strcmp(argv[1], "overflow");
    const bool concurrent = !strcmp(argv[1], "concurrent");
    perf_event_attr attr{};
    attr.size = sizeof(attr);
    attr.type = PERF_TYPE_SOFTWARE;
    attr.config = PERF_COUNT_SW_DUMMY;
    attr.disabled = 1;
    attr.exclude_kernel = 1;
    attr.exclude_hv = 1;
    attr.sample_type = PERF_SAMPLE_TID | PERF_SAMPLE_TIME;
    attr.sample_id_all = 1;
    attr.context_switch = 1;
    attr.use_clockid = 1;
    attr.clockid = CLOCK_MONOTONIC;
    attr.read_format = 1ULL << 4;
    const int fd = syscall(SYS_perf_event_open, &attr, 0, -1, -1, PERF_FLAG_FD_CLOEXEC);
    if (fd < 0) {
        printf("{\"available\":false,\"operation\":\"perf_event_open\",\"errno\":%d}\n", errno);
        return 2;
    }
    const size_t page = sysconf(_SC_PAGESIZE);
    const size_t length = page * ((overflow || concurrent) ? 2 : 65);
    void* mapping = mmap(nullptr, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (mapping == MAP_FAILED) { perror("mmap"); close(fd); return 3; }
    auto* metadata = static_cast<perf_event_mmap_page*>(mapping);
    if (metadata->data_offset != page || metadata->data_size != length - page) return 4;
    auto* ring = static_cast<unsigned char*>(mapping) + metadata->data_offset;
    std::vector<unsigned char> bytes(4 * 1024 * 1024);
    size_t count = 0;
    uint64_t wrapped = 0;
    uint64_t drains = 0;
    int drain_error = 0;
    const auto drain = [&]() {
        const uint64_t head = __atomic_load_n(&metadata->data_head, __ATOMIC_ACQUIRE);
        uint64_t tail = metadata->data_tail;
        if (head < tail || head - tail > metadata->data_size) { drain_error = 8; return; }
        if (head != tail) ++drains;
        while (tail < head) {
            perf_event_header header{};
            if (head - tail < sizeof(header)) { drain_error = 11; return; }
            copy_ring(reinterpret_cast<unsigned char*>(&header), ring, metadata->data_size, tail, sizeof(header));
            if (header.size < sizeof(header) || header.size > head - tail) { drain_error = 12; return; }
            if (count + header.size > bytes.size()) { drain_error = 13; return; }
            if (tail % metadata->data_size + header.size > metadata->data_size) ++wrapped;
            copy_ring(bytes.data() + count, ring, metadata->data_size, tail, header.size);
            count += header.size;
            tail += header.size;
        }
        __atomic_store_n(&metadata->data_tail, tail, __ATOMIC_RELEASE);
    };
    std::atomic<bool> stop{false};
    std::thread collector;
    if (concurrent) collector = std::thread([&]() {
        while (!stop.load(std::memory_order_acquire)) {
            drain();
            if (drain_error) return;
            timespec interval{0, 100000};
            nanosleep(&interval, nullptr);
        }
    });
    const uint64_t enable_before = now();
    if (ioctl(fd, PERF_EVENT_IOC_ENABLE, 0)) _exit(5);
    const uint64_t enable_after = now();
    const uint64_t work_start = now();
    const int iterations = (overflow || concurrent) ? 4000 : 100;
    for (int i = 0; i < iterations; ++i) {
        timespec duration{0, (overflow || concurrent) ? 50000L : 1000000L};
        while (nanosleep(&duration, &duration)) if (errno != EINTR) _exit(6);
    }
    const uint64_t sleep_end = now();
    const uint64_t busy_until = sleep_end + 200000000;
    uint64_t iterations_busy = 0;
    while (now() < busy_until) ++iterations_busy;
    const uint64_t work_end = now();
    const uint64_t disable_before = now();
    if (ioctl(fd, PERF_EVENT_IOC_DISABLE, 0)) _exit(7);
    const uint64_t disable_after = now();
    stop.store(true, std::memory_order_release);
    if (collector.joinable()) collector.join();
    if (!drain_error) drain();
    uint64_t counters[2]{};
    if (read(fd, counters, sizeof(counters)) != sizeof(counters)) return 9;
    FILE* output = fopen("/output/records.bin", "wb");
    if (!output || fwrite(bytes.data(), 1, count, output) != count || fclose(output)) return 10;
    FILE* collection = fopen("/output/collection.json", "w");
    if (!collection) return 14;
    fprintf(collection, "{\"wrappedRecords\":%llu,\"nonemptyDrains\":%llu,\"drainError\":%d,\"copyChecks\":384}\n",
        (unsigned long long)wrapped, (unsigned long long)drains, drain_error);
    if (fclose(collection)) return 15;
    printf("{\"available\":true,\"pid\":%d,\"tid\":%ld,\"attributeSize\":%zu,\"mode\":\"%s\",\"enableBefore\":%llu,\"enableAfter\":%llu,\"workStart\":%llu,\"sleepEnd\":%llu,\"workEnd\":%llu,\"disableBefore\":%llu,\"disableAfter\":%llu,\"bytes\":%zu,\"ringSize\":%llu,\"counter\":%llu,\"lost\":%llu,\"busyIterations\":%llu}\n",
        getpid(), syscall(SYS_gettid), sizeof(attr), argv[1],
        (unsigned long long)enable_before, (unsigned long long)enable_after,
        (unsigned long long)work_start, (unsigned long long)sleep_end,
        (unsigned long long)work_end, (unsigned long long)disable_before,
        (unsigned long long)disable_after, count, (unsigned long long)metadata->data_size,
        (unsigned long long)counters[0], (unsigned long long)counters[1],
        (unsigned long long)iterations_busy);
    munmap(mapping, length);
    close(fd);
    return drain_error;
}
