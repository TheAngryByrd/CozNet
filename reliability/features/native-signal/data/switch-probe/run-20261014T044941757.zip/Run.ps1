$ErrorActionPreference = 'Stop'
$run = Join-Path $PSScriptRoot ('run-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfff'))
New-Item -ItemType Directory $run | Out-Null
$image = & docker image inspect coznet-native-build:10.0.100 --format '{{.Id}}'
if ($LASTEXITCODE -ne 0) { throw 'Missing build image.' }
Copy-Item (Join-Path $PSScriptRoot 'probe.cpp') $run
& docker run --rm --pull never --network none --cap-drop ALL --read-only --tmpfs /tmp --mount "type=bind,source=$run,target=/output" $image timeout -k 2s 30s clang++ -std=c++17 -O2 -Wall -Wextra -Werror -pthread /output/probe.cpp -o /output/probe *> (Join-Path $run 'build.log')
if ($LASTEXITCODE -ne 0) { throw "Build failed: $run" }
$kernel = & docker run --rm --network none --cap-drop ALL --read-only $image uname -r
$outcomes = @()
foreach ($case in @('enabled-concurrent')) {
    $directory = Join-Path $run $case
    New-Item -ItemType Directory $directory | Out-Null
    $security = if ($case.StartsWith('enabled')) { @('--security-opt', 'seccomp=unconfined') } else { @() }
    $mode = 'concurrent'
    & docker run --rm --pull never --network none --cap-drop ALL --read-only @security --mount "type=bind,source=$run,target=/probe,readonly" --mount "type=bind,source=$directory,target=/output" $image timeout -k 2s 10s /probe/probe $mode 1> (Join-Path $directory 'summary.json') 2> (Join-Path $directory 'stderr.txt')
    $outcomes += @{ case=$case; exitCode=$LASTEXITCODE }
}
@{ image=$image; kernel=$kernel; sourceSha256=(Get-FileHash (Join-Path $run 'probe.cpp')).Hash; binarySha256=(Get-FileHash (Join-Path $run 'probe')).Hash; outcomes=$outcomes } | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $run 'environment.json')
$run
