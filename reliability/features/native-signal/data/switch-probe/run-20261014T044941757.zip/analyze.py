import dataclasses
import json
import pathlib
import struct
import sys


@dataclasses.dataclass(frozen=True)
class Switch:
    time: int
    out: bool
    preempt: bool


@dataclasses.dataclass(frozen=True)
class Loss:
    time: int
    count: int


def decode(data, pid, tid, start, end):
    records = []
    offset = 0
    previous = start
    while offset < len(data):
        if len(data) - offset < 8:
            raise ValueError("Truncated header")
        kind, flags, size = struct.unpack_from("<IHH", data, offset)
        if kind not in (2, 14):
            raise ValueError("Unexpected record type")
        expected = 24 if kind == 14 else 40
        if size != expected or offset + size > len(data):
            raise ValueError("Invalid record size")
        record_pid, record_tid, time = struct.unpack_from("<IIQ", data, offset + size - 16)
        if (record_pid, record_tid) != (pid, tid):
            raise ValueError("Unexpected identity")
        if not previous <= time <= end:
            raise ValueError("Timestamp outside ordered collection boundary")
        previous = time
        if kind == 14:
            if flags & ~(7 | (1 << 13) | (1 << 14)):
                raise ValueError("Unexpected switch flags")
            out = bool(flags & (1 << 13))
            preempt = bool(flags & (1 << 14))
            if preempt and not out:
                raise ValueError("Preempt flag on switch-in")
            records.append(Switch(time, out, preempt))
        else:
            _, count = struct.unpack_from("<QQ", data, offset + 8)
            if count == 0:
                raise ValueError("Empty loss record")
            records.append(Loss(time, count))
        offset += size
    return records


def intervals(records):
    pending = None
    state = "unknown"
    paired = []
    left_censored = 0
    for record in records:
        if isinstance(record, Loss):
            pending = None
            state = "unknown"
        elif record.out:
            if state == "out":
                raise ValueError("Repeated switch-out without reported loss")
            pending = record
            state = "out"
        else:
            if state == "in":
                raise ValueError("Repeated switch-in without reported loss")
            if pending is None:
                left_censored += 1
            else:
                paired.append({"start": pending.time, "end": record.time,
                               "duration": record.time - pending.time,
                               "preempt": pending.preempt})
            pending = None
            state = "in"
    return paired, left_censored, pending is not None


def analyze(directory):
    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8-sig"))
    if not summary["available"]:
        return {"available": False, "complete": False, "errno": summary["errno"]}
    keys = ["enableBefore", "enableAfter", "workStart", "sleepEnd", "workEnd", "disableBefore", "disableAfter"]
    times = [summary[key] for key in keys]
    if times != sorted(times):
        raise ValueError("Unordered workload boundaries")
    data = (directory / "records.bin").read_bytes()
    if len(data) != summary["bytes"]:
        raise ValueError("Byte count mismatch")
    records = decode(data, summary["pid"], summary["tid"], times[0], times[-1])
    paired, left, right = intervals(records)
    reported_loss = sum(r.count for r in records if isinstance(r, Loss))
    if reported_loss > summary["lost"]:
        raise ValueError("Loss records exceed final counter")
    complete = summary["lost"] == 0
    if summary["mode"] == "normal" and (not complete or len(paired) < 100):
        raise ValueError("Normal capture missing required sleep observations")
    if summary["mode"] == "overflow" and not summary["lost"] > reported_loss:
        raise ValueError("Overflow did not demonstrate trailing loss")
    if summary["mode"] == "concurrent":
        collection = json.loads((directory / "collection.json").read_text())
        if collection["drainError"] or collection["copyChecks"] != 384:
            raise ValueError("Ring collection checks failed")
        if not complete or len(paired) < 4000:
            raise ValueError("Concurrent capture missing required sleep observations")
        if collection["wrappedRecords"] == 0 or collection["nonemptyDrains"] < 2:
            raise ValueError("Concurrent capture did not exercise wrapped records and repeated drains")
    return {"available": True, "complete": complete, "records": len(records),
            "pairedIntervals": len(paired), "leftCensored": left, "rightCensored": right,
            "preemptOut": sum(r.out and r.preempt for r in records if isinstance(r, Switch)),
            "lossInRecords": reported_loss, "finalLoss": summary["lost"],
            "observedSwitchedOutNanoseconds": sum(i["duration"] for i in paired),
            "intervals": paired}


if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1])
    result = {case.name: analyze(case) for case in sorted(root.iterdir())
              if case.is_dir() and (case / "summary.json").exists()}
    (root / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
