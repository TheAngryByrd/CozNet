import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())

hashes = read(root / 'measured-hashes.json')
for name, expected in hashes.items():
    assert hashlib.sha256((root / 'measured' / name).read_bytes()).hexdigest().upper() == expected

transition_dir, = (root / 'transitions').glob('run-*')
sampled_dir, = (root / 'sampled').glob('run-*')
transitions, sampled = [], []
for outcome in read(transition_dir / 'outcomes.json'):
    assert outcome['exitCode'] == 0 and outcome['recordExists']
    if 'file' not in outcome:
        continue
    case = read(transition_dir / outcome['file'])
    assert case['passed'] and case['joined'] and case['restored'] and case['drained']
    assert case['nativeRange']['waitMode'] == 'spin'
    kinds = {r['AddressKind'] for r in case['requests']}
    if case['scenario'] == 'Jit':
        assert 'jit' in kinds
    if case['scenario'] == 'Transitions':
        assert {'selected','native-fixture'} <= kinds
    else:
        assert all(r['Result']['Outcome'] == 1 and r['Result']['WaitNanoseconds'] == 0 for r in case['requests'])
    if case['forcedGc']:
        assert case['collections'] and max(r['CallMilliseconds'] for r in case['collections']) <= 250
    transitions.append(dict(file=outcome['file'], requests=len(case['requests']), kinds=sorted(kinds)))

for outcome in read(sampled_dir / 'outcomes.json'):
    assert outcome['recordExists']
    if 'file' not in outcome:
        assert outcome['exitCode'] == 0
        continue
    case = read(sampled_dir / outcome['file'])
    assert case['backendDetails']['waitMode'] == 'spin'
    assert case['passed'] == (outcome['exitCode'] == 0)
    assert case['protocolPassed'] and case['joined'] and case['restored'] and case['gcJoined']
    assert case['forcedGc'] == (outcome['gcMode'] == 'gc')
    records = case['gcObservations'] or []
    start, finish = case['measurementStartedTimestamp'], case['measurement']['Timestamp']
    reached = [r for r in records if start <= r['StartedTimestamp'] <= r['FinishedTimestamp'] <= finish]
    if case['forcedGc']:
        assert reached
    else:
        assert not records
    for record in records:
        assert 0 < record['StartedTimestamp'] <= record['FinishedTimestamp']
        assert record['CollectionIndex'] > 0 and all(v >= 0 for v in record['PauseTicks'])
    durations = [1000*(r['FinishedTimestamp']-r['StartedTimestamp'])/case['stopwatchFrequency'] for r in records]
    assert max(durations,default=0) <= 250
    maximum = max(case['maxDebtNanoseconds'] + case['measurement']['DebtNanoseconds'])
    assert case['capacityPassed'] == (maximum <= 2000000)
    sampled.append(dict(file=outcome['file'], block=outcome['iteration'], gc=case['forcedGc'], percent=case['percent'],
        protocolPassed=case['protocolPassed'], capacityPassed=case['capacityPassed'], measurementCollections=len(reached),
        maximumGcCallMilliseconds=max(durations,default=0), peakPeerDebtMilliseconds=case['maxDebtNanoseconds'][1]/1e6,
        maximumHandlerMilliseconds=max((r['Result']['MeasuredHandlerNanoseconds']/1e6 for r in case['requests']),default=0)))

assert len(transitions) == 8 and len(sampled) == 12
assert {(r['block'],r['gc'],r['percent']) for r in sampled} == {(b,g,p) for b in (1,2,3) for g in (False,True) for p in (0,50)}
(root / 'analysis.json').write_text(json.dumps(dict(hashesVerified=len(hashes),transitions=transitions,sampled=sampled),indent=2))
