$ErrorActionPreference = 'Stop'
function Require([bool]$Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
$rows = @(foreach ($file in Get-ChildItem $PSScriptRoot -Filter 'block-*-speedup-*.json') {
    $case = Get-Content $file -Raw | ConvertFrom-Json
    $stages = @()
    if ($null -ne $case.warmup) {
        $stages += @{ name='warmup'; start=$case.warmup.RuntimeCountersStart; end=$case.warmup.Measurement.RuntimeCounters; checks=$case.warmup.PeerChecks; skips=$case.warmup.PeerCheckSkips }
    }
    if ($null -ne $case.measurement) {
        $stages += @{ name='measurement'; start=$case.runtimeCountersStart; end=$case.measurement.RuntimeCounters; checks=$case.peerChecks; skips=$case.peerCheckSkips }
    } else {
        Require ($null -ne $case.failureBoundary) 'Incomplete process has no failure boundary.'
        $stages += @{ name=$case.failureBoundary.Stage; start=$case.runtimeCountersStart; end=$case.failureBoundary.RuntimeCounters; checks=$case.peerChecks; skips=$case.peerCheckSkips }
    }
    foreach ($stage in $stages) {
        Require ($stage.start.Stage -eq $stage.name -and $stage.end.Stage -eq $stage.name) 'Counter stages disagree.'
        $snapshots = @($stage.start) + @($case.boundaries | Where-Object Stage -EQ $stage.name | ForEach-Object RuntimeCounters) + @($stage.end)
        $snapshots = @($snapshots | Sort-Object StartedTimestamp -Unique)
        $previous = $null
        foreach ($snapshot in $snapshots) {
            Require ($snapshot.StartedTimestamp -le $snapshot.FinishedTimestamp) 'Counter read interval is invalid.'
            if ($null -ne $previous) {
                Require ($previous.FinishedTimestamp -le $snapshot.StartedTimestamp) 'Counter reads overlap.'
                foreach ($field in @('ControllerAllocatedBytes','Gen0Collections','Gen1Collections','Gen2Collections','GcPauseTicks','ProcessCpuTicks')) {
                    Require ($snapshot.$field -ge $previous.$field) "Counter decreased: $field"
                }
            }
            $previous = $snapshot
        }
        Require ($stage.checks -ge 0 -and $stage.skips -gt 0) 'Peer counts are missing or invalid.'
        [pscustomobject]@{
            file=$file.Name; stage=$stage.name; measurementCompleted=($null -ne $case.measurement)
            protocolPassed=$case.protocolPassed; capacityPassed=$case.capacityPassed
            peerChecks=$stage.checks; peerCheckSkips=$stage.skips; snapshotsVerified=$snapshots.Count
            allocatedBytes=$stage.end.ControllerAllocatedBytes-$stage.start.ControllerAllocatedBytes
            gcPauseTicks=$stage.end.GcPauseTicks-$stage.start.GcPauseTicks
            gen0Collections=$stage.end.Gen0Collections-$stage.start.Gen0Collections
            gen1Collections=$stage.end.Gen1Collections-$stage.start.Gen1Collections
            gen2Collections=$stage.end.Gen2Collections-$stage.start.Gen2Collections
        }
    }
})
$rows | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $PSScriptRoot 'counter-analysis.json')

