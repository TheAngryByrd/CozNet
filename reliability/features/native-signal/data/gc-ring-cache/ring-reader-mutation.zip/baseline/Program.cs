using System.Buffers.Binary;
using System.Runtime.InteropServices;
RingReaderChecks.Run();
interface IInstructionMap { string? Resolve(ulong address); }
sealed record SampleBatch(int Samples, int DistinctInstructionPointers, ulong RepresentedCpuNanoseconds,
    int LostRecords, ulong LostSamples, int Throttles, int SelectedMethodSamples, int UnmappedSamples,
    IReadOnlyList<string> SelectedSymbols);
sealed record CpuSample
{
    public uint ProcessId { get; }
    public uint ThreadId { get; }
    public ulong Timestamp { get; }
    public ulong PeriodNanoseconds { get; }
    public ulong InstructionPointer { get; }
    public string? Method { get; }

    private CpuSample(uint processId, uint threadId, ulong timestamp, ulong period,
        ulong instructionPointer, string? method)
    {
        ProcessId = processId;
        ThreadId = threadId;
        Timestamp = timestamp;
        PeriodNanoseconds = period;
        InstructionPointer = instructionPointer;
        Method = method;
    }

    public static CpuSample Create(uint processId, uint threadId, ulong timestamp, ulong period,
        ulong instructionPointer, string? method)
    {
        if (processId == 0 || threadId == 0 || period == 0 || instructionPointer == 0)
            throw new InvalidDataException("Invalid CPU sample identity, period, or instruction address.");
        return new CpuSample(processId, threadId, timestamp, period, instructionPointer, method);
    }
}

interface ICpuSampleSink
{
    void Publish(CpuSample sample);
}

sealed class RingReader(IntPtr mapping, ulong offset, ulong size, long tid,
    IInstructionMap codeMap, string selectedSymbol, ICpuSampleSink sink)
{
    private SampleBatch? snapshot;
    private ulong tail = (ulong)Marshal.ReadInt64(mapping, 1032);
    private ulong priorTime;
    private int samples = 0, lostRecords = 0, throttles = 0;
    private ulong lostSamples = 0, periods = 0;
    private readonly HashSet<ulong> ips = new();

    private readonly HashSet<string> selectedSymbols = new();
    private int selected = 0, unmapped = 0;

    private byte[] Copy(ulong position, int length)
    {
        var bytes = new byte[length];
        for (int i = 0; i < length; i++) bytes[i] = Marshal.ReadByte(mapping + checked((int)(offset + ((position + (ulong)i) % size))));
        return bytes;
    }
    public SampleBatch Drain()
    {
        ulong head = (ulong)Marshal.ReadInt64(mapping, 1024);
        Thread.MemoryBarrier();
        if (head < tail || head - tail > size) throw new Exception("Ring bounds are invalid.");
        if (head == tail && snapshot is not null) return snapshot;
        snapshot = null;
        while (tail < head)
        {
            if (head - tail < 8) throw new Exception("Truncated record header.");
            byte[] header = Copy(tail, 8);
            uint type = BinaryPrimitives.ReadUInt32LittleEndian(header);
            ushort misc = BinaryPrimitives.ReadUInt16LittleEndian(header.AsSpan(4));
            ushort length = BinaryPrimitives.ReadUInt16LittleEndian(header.AsSpan(6));
            if (length < 8 || length > head - tail) throw new Exception("Invalid record length.");
            byte[] record = Copy(tail, length);
            if (type == 9)
            {
                if (length != 40 || (misc & 7) != 2) throw new Exception("Unexpected sample layout or CPU mode.");
                ulong ip = BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(8));
                uint recordedPid = BinaryPrimitives.ReadUInt32LittleEndian(record.AsSpan(16));
                uint recordedTid = BinaryPrimitives.ReadUInt32LittleEndian(record.AsSpan(20));
                ulong timestamp = BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(24));
                ulong period = BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(32));
                if (ip == 0 || recordedPid != Environment.ProcessId || recordedTid != tid || timestamp < priorTime || period == 0)
                    throw new Exception("Invalid sample attribution metadata.");
                ips.Add(ip); priorTime = timestamp; periods += period; samples++;
                string? symbol = codeMap.Resolve(ip);
                sink.Publish(CpuSample.Create(recordedPid, recordedTid, timestamp, period, ip, symbol));

                if (symbol is null) unmapped++;
                else if (string.Equals(symbol, selectedSymbol, StringComparison.Ordinal)) { selected++; selectedSymbols.Add(symbol); }
            }
            else if (type == 2)
            {
                if (length != 24) throw new Exception("Unexpected lost-record layout.");
                lostRecords++; lostSamples += BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(16));
            }
            else if (type is 5 or 6) throttles++;
            else throw new Exception($"Unexpected perf record type {type}.");
            tail += length;
        }
        Thread.MemoryBarrier();
        Marshal.WriteInt64(mapping, 1032, (long)tail);
        snapshot = new SampleBatch(samples, ips.Count, periods, lostRecords, lostSamples, throttles,
            selected, unmapped, Array.AsReadOnly(selectedSymbols.Order().ToArray()));
        return snapshot;
    }
}

