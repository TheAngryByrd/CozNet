using CozNet;
using System.Runtime.CompilerServices;
using System.Text.Json;

var state = SignalAccountingModule.create();
long sum = 0;
for (int i = 0; i < 10000; i++) sum += Read(state);
long before = GC.GetAllocatedBytesForCurrentThread();
for (int i = 0; i < 100000; i++) sum += Read(state);
long allocated = GC.GetAllocatedBytesForCurrentThread() - before;
File.WriteAllText(args[0], JsonSerializer.Serialize(new { runtime=Environment.Version.ToString(), calls=100000, allocatedBytes=allocated, sum }));

[MethodImpl(MethodImplOptions.NoInlining)]
static long Read(SignalAccounting state) => SignalAccountingModule.globalNanoseconds(state);
